package com.example.SeaweedSystem.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SeaweedSystem.Entity.Complain;
import com.example.SeaweedSystem.Repository.ComplainRepository;

@Service
public class ComplainServiceImpl implements ComplainService{
	
	@Autowired
	public ComplainRepository complainRepository;

	@Override
	public List<Complain> getAllComplain() {
		// TODO Auto-generated method stub
		return complainRepository.findAll() ;
	}

	@Override
	public void saveComplain(Complain complain) {
		// TODO Auto-generated method stub
		this.complainRepository.save(complain);
	}

	@Override
	public Complain getComplainById(Long Id) {
	
		Optional<Complain> optional = complainRepository.findById(Id);
		Complain complain = null;
		
		if(optional.isPresent()) {
			
			complain = optional.get();
		}else {
			
			throw new RuntimeException("Complain not found for id " + Id);
			
		}

		return  complain;
	}

	
}
