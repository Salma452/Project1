package com.example.SeaweedSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.SeaweedSystem.Entity.Farmer;
import com.example.SeaweedSystem.Services.FarmerService;

@Controller
public class FarmerController {
	@Autowired
	private  FarmerService farmerService ;
	
	

	@GetMapping("/showFarmer")
	public String showFarmer(Model model) {
		Farmer farmer = new Farmer();
		model.addAttribute("farmer", farmer);
		return "Farmer";
	}
	

	@GetMapping("/saveFarmer")
	public String saveFarmer(@ModelAttribute("farmer")Farmer farmer ) {
		farmerService.saveFarmer(farmer);
	return "redirect:/hom";
	
	}

	@GetMapping("/ViewFarmer")
	public String ViewFarmer(Model model) {
		model.addAttribute("listFarmer", farmerService.getAllFarmer());
		return "ViewFarmer";
	}

}
