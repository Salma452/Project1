package com.example.SeaweedSystem.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Complain {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long ComplainId;

	@Column(length = 50, nullable = false)
	private String Name;
	
	@Column(length = 50, nullable = false)
	private String Address;
	
	
	
	@Column(length = 50, nullable = false)
	private String Complain;


	
	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "FarmerId") private Farmer FarmerId;
	 */

	public Complain() {
		super();
	}



	public Complain(Long complainId, String name, String address, String complain) {
		super();
		ComplainId = complainId;
		Name = name;
		Address = address;
		Complain = complain;
	}



	public Long getComplainId() {
		return ComplainId;
	}



	public void setComplainId(Long complainId) {
		ComplainId = complainId;
	}



	public String getName() {
		return Name;
	}



	public void setName(String name) {
		Name = name;
	}



	public String getAddress() {
		return Address;
	}



	public void setAddress(String address) {
		Address = address;
	}



	public String getComplain() {
		return Complain;
	}



	public void setComplain(String complain) {
		Complain = complain;
	}


	
	
}
