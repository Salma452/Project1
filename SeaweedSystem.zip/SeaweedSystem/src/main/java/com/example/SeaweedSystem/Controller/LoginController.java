package com.example.SeaweedSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.SeaweedSystem.Entity.Users;
import com.example.SeaweedSystem.Services.LoginService;

@Controller
public class LoginController {
	@GetMapping("/loginn")
	public String Home() {
		return "login";
		
	}
	
	@Autowired LoginService loginservice;
	@PostMapping("/login")
	public String loginI(Model model,@RequestParam String userName, @RequestParam String password ) {
		List<Users> login = loginservice.login(userName, password);
		Users users = new Users();
		for(Users st:login) {
			users.setRole(st.getRole());
		
		} if(login.size()>0) {
			if(users.getRole().equals("Admin")) {
				
				return"redirect:/adminhome";
				
			} if(users.getRole().equals("Farmer")) {
					
					return"redirect:/hom";
					
		}else {
			return "redirect:/dash";
		}
	}
			else {
				return "login";
			}
			
	}
}


