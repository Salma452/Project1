package com.example.SeaweedSystem.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Booking")
public class Booking {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long BookingId;

	@Column(length = 50, nullable = false)
	private String NameOfBuyer;
	
	@Column(length = 50, nullable = false)
	private String Date;
	
	
	
	@Column(length = 50, nullable = false)
	private String Amount;

	@Column(length = 50, nullable = false)
	private String Time;
	
	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "UserId") private Users UserId;
	 */
	

	
	public Booking() {
		super();
	}



	
	public Booking(Long bookingId, String nameOfBuyer, String date, String amount, String time) {
	super();
	BookingId = bookingId;
	NameOfBuyer = nameOfBuyer;
	Date = date;
	Amount = amount;
	Time = time;
}




	




	public Long getBookingId() {
		return BookingId;
	}




	public void setBookingId(Long bookingId) {
		BookingId = bookingId;
	}




	public String getNameOfBuyer() {
		return NameOfBuyer;
	}




	public void setNameOfBuyer(String nameOfBuyer) {
		NameOfBuyer = nameOfBuyer;
	}




	public String getDate() {
		return Date;
	}




	public void setDate(String date) {
		Date = date;
	}




	public String getAmount() {
		return Amount;
	}




	public void setAmount(String amount) {
		Amount = amount;
	}




	public String getTime() {
		return Time;
	}




	public void setTime(String time) {
		Time = time;
	}





}
