package com.example.SeaweedSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class SeaweedSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeaweedSystemApplication.class, args);
		
	}

}