package com.example.SeaweedSystem.Repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.SeaweedSystem.Entity.Users;
@Repository
public interface UsersRepository  extends JpaRepository<Users, Long> {
	List<Users> findByUserNameAndPassword(String userName, String password);


}
