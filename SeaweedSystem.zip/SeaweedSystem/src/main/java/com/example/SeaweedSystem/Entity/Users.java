package com.example.SeaweedSystem.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Users")
public class Users {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long UserId;

	@Column(length = 50, nullable = false)
	private String userName;
	
	@Column(length = 50, nullable = false)
	private String password;

	
	@Column(length = 50, nullable = false)
	private String Address;
	
	
	@Column(length = 50, nullable = false)
	private String Email;

	@Column(length = 50, nullable = false)
	private String phoneNumber;
	
	
	@Column(length = 50, nullable = false)
	private String role;

	
	/*
	 * @OneToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "FarmerId") private Farmer farmer;
	 * 
	 * 
	 * @OneToMany(targetEntity = Booking.class, cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "UserId", referencedColumnName = "UserId") private
	 * List<Booking> booking;
	 */
	 

	public Users(Long userId, String userName, String password, String address, String email, String phoneNumber,
			String role) {
		super();
		UserId = userId;
		this.userName = userName;
		this.password = password;
		Address = address;
		Email = email;
		this.phoneNumber = phoneNumber;
		this.role = role;
	}

	public Users() {
		// TODO Auto-generated constructor stub
	}

	public Long getUserId() {
		return UserId;
	}

	public void setUserId(Long userId) {
		UserId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	

}
