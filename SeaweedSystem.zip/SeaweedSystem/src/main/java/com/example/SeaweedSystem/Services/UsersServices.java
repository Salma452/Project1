package com.example.SeaweedSystem.Services;

import java.util.List;

import com.example.SeaweedSystem.Entity.Users;

public interface UsersServices {

	
	List<Users> getAllUsers();

	void saveUsers(Users users);
	
	
	Users getUsersById(Long UserId);
	
	void deleteUsers(Long UserId);

	List<Users> getByuserName(String userName);
	
	
	
	 
	
}
