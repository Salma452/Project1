package com.example.SeaweedSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.SeaweedSystem.Entity.Booking;
import com.example.SeaweedSystem.Services.BookingService;
import com.example.SeaweedSystem.Services.BookingServiceImpl;

@Controller
public class BookingController {


	@Autowired
	private  BookingService bookingService ;

	@GetMapping("/showBooking")
	public String showBooking(Model model) {
		Booking booking = new Booking();
		model.addAttribute("booking", booking);
		return "Booking";
	}
	

	@GetMapping("/saveBooking")
	public String saveBooking(@ModelAttribute("booking")Booking booking ) {
		bookingService.saveBooking(booking);
	return "redirect:/ViewProduct";
	
	}
	
	@GetMapping("/ViewBooking")
	public String ViewBooking(Model model) {
		model.addAttribute("listBooking", bookingService.getAllBooking());
		return "ViewBooking";
	
}
	@GetMapping("/AdminBooking")
	public String AdminBooking(Model model) {
		model.addAttribute("listBooking", bookingService.getAllBooking());
		return "AdminBooking";
	
}
}