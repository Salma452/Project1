package com.example.SeaweedSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.SeaweedSystem.Entity.Complain;
import com.example.SeaweedSystem.Services.ComplainService;

@Controller
public class ComplainController {
	
	@Autowired
	private  ComplainService complainService ;
	
	

	@GetMapping("/showComplain")
	public String showComplain(Model model) {
		Complain complain = new Complain();
		model.addAttribute("complain", complain);
		return "Complain";
	}
	

	@GetMapping("/saveComplain")
	public String saveComplain(@ModelAttribute("complain")Complain complain ) {
		complainService.saveComplain(complain);
	return "redirect:/hom";
	
	}


	@GetMapping("/ViewComplain")
	public String ViewComplain(Model model) {
		model.addAttribute("listComplain", complainService.getAllComplain());
		return "ViewComplain";
	}
}
