package com.example.SeaweedSystem.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long ProductId;

	@Column(length = 50, nullable = false)
	private String Amount;
	
	@Column(length = 50, nullable = false)
	private String Price;

	
	@Column(length = 50, nullable = false)
	private String TypeOfSeaweed;

	
	
	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "FarmerId")
	 */
	/*
	 * private Farmer FarmerId;
	 */
	

	public Product() {
		super();
	}


	public Product(Long productId, String amount, String price, String typeOfSeaweed) {
		super();
		ProductId = productId;
		Amount = amount;
		Price = price;
		TypeOfSeaweed = typeOfSeaweed;
	}


	public Long getProductId() {
		return ProductId;
	}


	public void setProductId(Long productId) {
		ProductId = productId;
	}


	public String getAmount() {
		return Amount;
	}


	public void setAmount(String amount) {
		Amount = amount;
	}


	public String getPrice() {
		return Price;
	}


	public void setPrice(String price) {
		Price = price;
	}


	public String getTypeOfSeaweed() {
		return TypeOfSeaweed;
	}


	public void setTypeOfSeaweed(String typeOfSeaweed) {
		TypeOfSeaweed = typeOfSeaweed;
	}
	

	
}
