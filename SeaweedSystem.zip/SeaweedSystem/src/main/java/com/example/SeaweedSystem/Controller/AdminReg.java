package com.example.SeaweedSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.SeaweedSystem.Entity.Users;
import com.example.SeaweedSystem.Services.UsersServices;

@Controller
public class AdminReg {

	@Autowired
	private  UsersServices userServices ;
	
	@GetMapping("/showUserRegister")
	public String showUserRegister(Model model) {
		Users users = new Users();
		model.addAttribute("users", users);
		return "AdminReg";
	}
	
	
	@PostMapping("/saveUserRegister")
	public String saveUserRegister(@ModelAttribute("users")Users users ) {
		userServices.saveUsers(users);
	return "redirect:/ViewRegister";
	
	}
	
}
