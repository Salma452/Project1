package com.example.SeaweedSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.SeaweedSystem.Entity.Users;
import com.example.SeaweedSystem.Services.UsersServices;

@Controller
public class UsersController {

	
	@Autowired
	private  UsersServices userServices ;
	
	
	@GetMapping("/ViewRegister")
	public String ViewRegister(Model model) {
		model.addAttribute("listUsers", userServices.getAllUsers());
		return "listUser";
	}

	@GetMapping("/showRegister")
	public String showRegister(Model model) {
		Users users = new Users();
		model.addAttribute("users", users);
		return "Register";
	}
	
	
	@PostMapping("/saveUsers")
	public String saveUsers(@ModelAttribute("users")Users users ) {
		userServices.saveUsers(users);
	return "redirect:/loginn";
	
	}

	@GetMapping("/updateUsers/{UserId}")
	public String showFormforupdate(@PathVariable (value = "UserId") Long UserId, Model model) {
		Users users = userServices.getUsersById(UserId);
		model.addAttribute("users", users);
		return "Update";
	}
	
	
	@GetMapping("/deleteUsers/{UserId}")
	public String deleteUsers(@PathVariable (value = "UserId") Long UserId) {
		this.userServices.deleteUsers(UserId);
		
		return "redirect:/ViewRegister";
	}
	
	@RequestMapping(value = "users", method = RequestMethod.GET)
	public String showStudentByuserName(@RequestParam (value = "search", required = false) String userName, Model model) {
	    model.addAttribute("search", userServices.listStudentsBySurname(search));
	    return "ViewRegister";
	
}
}
