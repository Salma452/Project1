package com.example.SeaweedSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.example.SeaweedSystem.Entity.Product;
import com.example.SeaweedSystem.Services.ProductService;

@Controller
public class ProductController {

	@Autowired
	private  ProductService productService ;
	
	
	@GetMapping("/showProduct")
	public String showProduct(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		return "Product";
	}
	

	@GetMapping("/saveProduct")
	public String saveProduct(@ModelAttribute("product")Product product ) {
		productService.saveProduct(product);
	return "redirect:/hom";
	
	}
	
	@GetMapping("/ViewProduct")
	public String ViewProduct(Model model) {
		model.addAttribute("listProduct", productService.getAllProduct());
		return "ViewProduct";
	}
	
	
	
	}
