package com.example.SeaweedSystem.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminDashboard {
	@GetMapping ("/adminhome")
	public String adminhome(Model model) {
		return "admin";
	}

}
