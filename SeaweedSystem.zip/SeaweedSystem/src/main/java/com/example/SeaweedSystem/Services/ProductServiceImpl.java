package com.example.SeaweedSystem.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SeaweedSystem.Entity.Product;
import com.example.SeaweedSystem.Repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	public ProductRepository productRepository;

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return productRepository.findAll() ;
	}

	@Override
	public void saveProduct(Product product) {
		// TODO Auto-generated method stub
		this.productRepository.save(product);
	}

	@Override
	public Product getProductById(Long Id) {
		// TODO Auto-generated method stub
		Optional<Product> optional = productRepository.findById(Id);
		Product product = null;
		
		if(optional.isPresent()) {
			
			product = optional.get();
		}else {
			
			throw new RuntimeException("Product not found for id " + Id);
			
		}

		return  product;
	}

	}
	
	


