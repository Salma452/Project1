package com.example.SeaweedSystem.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SeaweedSystem.Entity.Users;
import com.example.SeaweedSystem.Repository.UsersRepository;

@Service
public class LoginService {
@Autowired UsersRepository usersRepository;
	
	public List<Users> login(String userName, String password){
		return usersRepository. findByUserNameAndPassword(userName, password);
	}
}
