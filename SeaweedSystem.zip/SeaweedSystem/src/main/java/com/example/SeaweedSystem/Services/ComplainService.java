package com.example.SeaweedSystem.Services;

import java.util.List;

import com.example.SeaweedSystem.Entity.Complain;

public interface ComplainService {

	List<Complain> getAllComplain();

	void saveComplain(Complain complain);
	
	Complain getComplainById(Long Id);
}
