package com.example.SeaweedSystem.Services;

import java.util.List;

import com.example.SeaweedSystem.Entity.Product;

public interface ProductService {
	
	List<Product> getAllProduct();

	void saveProduct(Product product);
	
	Product getProductById(Long Id);
	
	

}
