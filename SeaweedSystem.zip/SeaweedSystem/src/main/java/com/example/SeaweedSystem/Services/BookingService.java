package com.example.SeaweedSystem.Services;

import java.util.List;

import com.example.SeaweedSystem.Entity.Booking;


public interface BookingService {

	List<Booking> getAllBooking();

	void saveBooking(Booking booking);
	
	Booking getBookingById(Long Id);
}
