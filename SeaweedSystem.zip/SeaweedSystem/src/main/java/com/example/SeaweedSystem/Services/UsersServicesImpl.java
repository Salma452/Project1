package com.example.SeaweedSystem.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SeaweedSystem.Entity.Users;
import com.example.SeaweedSystem.Repository.UsersRepository;

@Service
public class UsersServicesImpl implements UsersServices {

	@Autowired
	public UsersRepository usersRepository;
	
	@Override
	public List<Users> getAllUsers() {
		return usersRepository.findAll() ;
	}

	@Override
	public void saveUsers(Users users) {
		this.usersRepository.save(users);
		
	}

	@Override
	public Users getUsersById(Long UserId) {
		Optional<Users> optional = usersRepository.findById(UserId);
		Users users = null;
		
		if(optional.isPresent()) {
			
			users = optional.get();
		}else {
			
			throw new RuntimeException("Users not found for id:" + UserId);
			
		}
		return  users; 		
	}

	@Override
	public void deleteUsers(Long UserId) {
		this.usersRepository.deleteById(UserId);
		
	}

	

	
	public List<Users> getByuserName(String userName) {
		// TODO Auto-generated method stub
		return null;
	}
		
		
	}

