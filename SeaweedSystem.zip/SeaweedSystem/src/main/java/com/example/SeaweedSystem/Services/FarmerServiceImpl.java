package com.example.SeaweedSystem.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SeaweedSystem.Entity.Farmer;
import com.example.SeaweedSystem.Repository.FarmerRepository;

@Service
public class FarmerServiceImpl implements FarmerService {
	
	@Autowired
	public FarmerRepository farmerRepository;

	@Override
	public List<Farmer> getAllFarmer() {
		// TODO Auto-generated method stub
		return farmerRepository.findAll() ;
	}

	@Override
	public void saveFarmer(Farmer farmer) {
		this.farmerRepository.save(farmer);
		
	}

	@Override
	public Farmer getFarmerById(Long Id) {
		// TODO Auto-generated method stub
	
		Optional<Farmer> optional = farmerRepository.findById(Id);
		Farmer farmer = null;
		
		if(optional.isPresent()) {
			
			farmer = optional.get();
		}else {
			
			throw new RuntimeException("Farmer not found for id " + Id);
			
		}

		return  farmer;
	}

	
	}

	
	

	
	
	
