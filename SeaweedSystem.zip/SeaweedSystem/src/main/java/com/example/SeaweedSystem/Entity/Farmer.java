package com.example.SeaweedSystem.Entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Farmer")

public class Farmer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long FarmerId;

	@Column(length = 50, nullable = false)
	private String Name;
	
	@Column(length = 50, nullable = false)
	private String District;

	
	@Column(length = 50, nullable = false)
	private String Region;
	
	
	@Column(length = 50, nullable = false)
	private String Village;

	@Column(length = 50, nullable = false)
	private String Gender;

	
	
	/*
	 * @OneToOne(mappedBy="farmer") private Users users;
	 * 
	 * 
	 * @OneToMany(targetEntity = Product.class, cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "FarmerId", referencedColumnName = "FarmerId") private
	 * List<Product> product;
	 * 
	 * @OneToMany(targetEntity = Complain.class, cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "FarmerId", referencedColumnName = "FarmerId") private
	 * List<Complain> complain;
	 */
 

	
	public Farmer() {
		// TODO Auto-generated constructor stub
	}
	

	public Farmer(Long farmerId, String name, String district, String region, String village, String gender
			) {
		super();
		FarmerId = farmerId;
		Name = name;
		District = district;
		Region = region;
		Village = village;
		Gender = gender;
		
	}

	


	public Long getFarmerId() {
		return FarmerId;
	}


	public void setFarmerId(Long farmerId) {
		FarmerId = farmerId;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getDistrict() {
		return District;
	}


	public void setDistrict(String district) {
		District = district;
	}


	public String getRegion() {
		return Region;
	}


	public void setRegion(String region) {
		Region = region;
	}


	public String getVillage() {
		return Village;
	}


	public void setVillage(String village) {
		Village = village;
	}


	public String getGender() {
		return Gender;
	}


	public void setGender(String gender) {
		Gender = gender;
	}


	
	
}
