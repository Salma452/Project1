package com.example.SeaweedSystem.Services;

import java.util.List;

import com.example.SeaweedSystem.Entity.Farmer;

public interface FarmerService {

	List<Farmer> getAllFarmer();

	void saveFarmer(Farmer farmer);
	

	Farmer getFarmerById(Long Id);
}
