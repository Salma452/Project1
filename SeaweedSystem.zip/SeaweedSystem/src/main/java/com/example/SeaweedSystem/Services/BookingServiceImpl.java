package com.example.SeaweedSystem.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SeaweedSystem.Entity.Booking;
import com.example.SeaweedSystem.Repository.BookingRepository;


@Service
public class BookingServiceImpl implements BookingService{
	
	@Autowired
	public BookingRepository bookingRepository;

	@Override
	public List<Booking> getAllBooking() {
		return bookingRepository.findAll() ;
	}
	

	@Override
	public void saveBooking(Booking booking) {
		this.bookingRepository.save(booking);
	}
	

	@Override
	public Booking getBookingById(Long Id) {
		Optional<Booking> optional = bookingRepository.findById(Id);
		Booking booking = null;
		
		if(optional.isPresent()) {
			
			booking = optional.get();
		}else {
			
			throw new RuntimeException("Booking not found for id " + Id);
			
		}

		return  booking;
	}

	
	

	}


