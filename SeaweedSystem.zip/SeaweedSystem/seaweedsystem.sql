-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2022 at 07:06 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seaweedsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `ComplainId` int(11) NOT NULL,
  `Comment` varchar(200) NOT NULL,
  `UserId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`ComplainId`, `Comment`, `UserId`) VALUES
(5, 'Hatuna vifaa vya kilimo', 29),
(6, 'tunahitaji elimu juu ya njia mpya au za kisasa za kufanyia kazi', 29);

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `DistrictId` int(11) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `DistrictName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`DistrictId`, `RegionId`, `DistrictName`) VALUES
(1, 3, 'WILAYA YA KATI'),
(2, 3, 'WILAYA YA KUSINI'),
(6, 2, 'WILAYA YA KASKAZINI');

-- --------------------------------------------------------

--
-- Table structure for table `ordertables`
--

CREATE TABLE `ordertables` (
  `OderID` int(11) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Dates` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ProductID` int(11) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordertables`
--

INSERT INTO `ordertables` (`OderID`, `Amount`, `Dates`, `ProductID`, `Status`, `Uid`) VALUES
(10, 10, '2022-06-29 19:56:44', 10, 'Confirmed', 30),
(11, 10, '2022-06-29 19:56:16', 11, 'Pending', 30);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` int(11) NOT NULL,
  `DatePay` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `RefrenceNumber` varchar(50) NOT NULL,
  `OredrID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `DatePay`, `RefrenceNumber`, `OredrID`) VALUES
(5, '2022-06-29 19:57:40', '2345598766', 10);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductId` int(11) NOT NULL,
  `TypeofProduct` varchar(200) NOT NULL,
  `Amount` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `UserId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductId`, `TypeofProduct`, `Amount`, `Price`, `UserId`) VALUES
(10, 'Cottonii', '20', '1200', 29),
(11, 'Spinosum', '12', '1500', 29);

-- --------------------------------------------------------

--
-- Table structure for table `region`
--

CREATE TABLE `region` (
  `RegionId` int(11) NOT NULL,
  `RegionName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`RegionId`, `RegionName`) VALUES
(2, 'MKOA WA KASKAZINI UNGUJA'),
(3, 'MKOA WA KUSINI UNGUJA'),
(11, 'KASKAZINI UNGUJA'),
(12, 'KASKAZINI A'),
(13, 'KASKAINI B');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserId` int(11) NOT NULL,
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Phonenumber` int(11) NOT NULL,
  `Role` varchar(200) NOT NULL,
  `VillageID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserId`, `Username`, `Password`, `Email`, `Phonenumber`, `Role`, `VillageID`, `Name`) VALUES
(28, 'Salmah', '12345', 'sal452@gmail.com', 774007439, 'Admin', 11, 'Sal'),
(29, 'Hidya', '00000', 'hidaya@gmail.com', 776875440, 'Farmer', 13, 'Hidaya'),
(30, 'Ali', '00000', 'ali@gmail.com', 987654321, 'Buyer', 10, 'Ali');

-- --------------------------------------------------------

--
-- Table structure for table `village`
--

CREATE TABLE `village` (
  `VillageId` int(11) NOT NULL,
  `DistrictId` int(11) NOT NULL,
  `VillageName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `village`
--

INSERT INTO `village` (`VillageId`, `DistrictId`, `VillageName`) VALUES
(5, 2, 'chwaka'),
(6, 2, 'Bwejuu'),
(8, 1, 'MICHAMVI'),
(9, 1, 'UROA'),
(10, 1, 'MARUMBI'),
(11, 2, 'JAMBIANI'),
(12, 2, 'MAKUNDUCHI'),
(13, 2, 'PAJE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`ComplainId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`DistrictId`),
  ADD KEY `RegionId` (`RegionId`);

--
-- Indexes for table `ordertables`
--
ALTER TABLE `ordertables`
  ADD PRIMARY KEY (`OderID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `OredrID` (`OredrID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`RegionId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD KEY `VillageID` (`VillageID`);

--
-- Indexes for table `village`
--
ALTER TABLE `village`
  ADD PRIMARY KEY (`VillageId`),
  ADD KEY `DistrictId` (`DistrictId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `ComplainId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `DistrictId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ordertables`
--
ALTER TABLE `ordertables`
  MODIFY `OderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `region`
--
ALTER TABLE `region`
  MODIFY `RegionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `village`
--
ALTER TABLE `village`
  MODIFY `VillageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complain`
--
ALTER TABLE `complain`
  ADD CONSTRAINT `complain_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `district`
--
ALTER TABLE `district`
  ADD CONSTRAINT `district_ibfk_1` FOREIGN KEY (`RegionId`) REFERENCES `region` (`RegionId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ordertables`
--
ALTER TABLE `ordertables`
  ADD CONSTRAINT `ordertables_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`OredrID`) REFERENCES `ordertables` (`OderID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`VillageID`) REFERENCES `village` (`VillageId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `village`
--
ALTER TABLE `village`
  ADD CONSTRAINT `village_ibfk_1` FOREIGN KEY (`DistrictId`) REFERENCES `district` (`DistrictId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
